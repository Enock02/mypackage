# package
This library was created as an example of hpw to publish your own python package

# how to install

